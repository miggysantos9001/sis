<?php

return [
    'en' => [
        'display' => 'English',
    ],
    'ch' => [
        'display' => 'Mandarin',
    ],
];