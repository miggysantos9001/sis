<?php

return [
    'system_name'	=>	'SIS V1',
]

?>